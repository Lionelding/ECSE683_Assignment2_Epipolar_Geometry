clc;
clear all;
close all;
im1 = imread('I11.jpg');
figure(1);
imshow(im1);
m1 = ginput(32);

